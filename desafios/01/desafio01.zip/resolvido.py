# pegadinha do daniel
# tente resolver primeiro
